# Q03c

# Write your code below this line
myValue = 1

while (myValue >=1 and myValue <=50):
    myValue = int(input("Enter a value between 1 and 50:"))
    if (myValue >= 1 and myValue <=50):
        print("Value: ",myValue,"square: ",myValue**2,"cube: ",myValue**3)
