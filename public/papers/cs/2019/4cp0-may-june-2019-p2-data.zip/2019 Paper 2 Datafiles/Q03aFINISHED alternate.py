# Q03a

#	Open the file and input data
inputFile = open('Email.txt','r')
emailList = inputFile.readlines() #Readlines reads each individual line in the file

#	Open output file
outputFile = open('Error.txt','a') #Add all emails addresses that are wrong into the fil

#	Find errors and write to output file
for address in emailList:
    if not "@" in address: #If it cannot find the @ symbol
        outputFile.write(address) #Add the wrong email address to the Error.txt file

#	Close files
outputFile.close()
inputFile.close()
