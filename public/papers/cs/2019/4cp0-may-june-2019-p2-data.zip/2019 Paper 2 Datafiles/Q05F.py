#Q05FINISHED

libraryRecord =  [
["105MS" , "Marcus" , "Smith" , 25 ],
["103AZ" , "Anthony" , "Zarrent" , 5 ],
["108MW" , "Matt" , "White" , 12 ],
["112DB" , "Denise" , "Bilton" , 58 ],
["124MK" , "Malcolm" , "Kelly" , 26 ],
["116UK" , "Uzere" , "Kevill" , 29 ],
["127AL" , "Abduraheim" , "Leahy" , 94 ],
["124LS" , "Laura" , "Sampras" , 50 ],
["121AP" , "Azra" , "Potter" , 61 ],
["115AC" , "Anthony" , "Calik" , 10 ],
["117PI" , "Pablo" , "Iilyas" , 49 ],
["113MM" , "Mark" , "Montgomerie" , 68 ],
["130FH" , "Felicity" , "Heath" , 11 ],
["132JA" , "Jill" , "Alexander" , 61 ],
["123SG" , "Sara" , "Grimstow" , 9 ],
["134KD" , "Kevin" , "Dawson" , 74 ],
["122AB" , "Andrew" , "Bertwistle" , 42 ],
["125JF" , "Jaide" , "Feehily" , 55 ],
["128JS" , "Justin" , "Slater" , 68 ],
["126CG" , "Colleen" , "Grohl" , 39 ]
]
# ----------------------------------------------
# Write your code below this line
total = 0
gold = 0
silver = 0
bronze = 0
goldID = 0
silverID = 0
bronzeID = 0

for row in range(len(libraryRecord)):
    books = int(libraryRecord[row][3])
    if (books > gold):
        bronze = silver
        silver = gold
        gold = books
        goldID = row
    elif (books > silver):
        bronze = silver
        silver = books
        silverID = row
    elif (books > bronze):
        bronze = books
        bronzeID = row
        
    total = total + books

if (books < 10):
    print("Pupil ID of pupils who have read less than 10 books.")
    print(libraryRecord[row][0])

print("Total number of books read by pupils: ", total)
print("Average number of books read by pupils: ", total / len(libraryRecord[0]))

print("Gold medal winner is: ", libraryRecord[goldID][1], " ", libraryRecord[goldID][2])
print("Silver medal winner is: ", libraryRecord[silverID][1], " ", libraryRecord[silverID][2])
print("Bronze medal winner is: ", libraryRecord[bronzeID][1], " ", libraryRecord[bronzeID][2])


        


        
