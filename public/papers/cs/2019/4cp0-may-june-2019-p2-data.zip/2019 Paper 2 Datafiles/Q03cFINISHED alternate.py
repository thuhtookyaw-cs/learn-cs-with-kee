# Q03c

# Write your code below this line

myValue = int(input("Enter a value between 1 and 50: "))
if (myValue >= 1 and myValue <= 50): #Conditional based on the value
    print("Value: ",myValue, "Square: ", myValue * 2, "Cube: ", myValue *3)
