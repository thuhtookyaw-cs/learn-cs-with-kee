# Q05

# Array of words
wordArray = ["wind","leer","pushy","lade","size","sob","borrowing","list",
             "perish","hoax","sticks","seed","impel","large","male","silent",
             "quilt","sobbed","remarkable","fantastic","wire","reflective","putrid", 
             "pushover","swing"]


# Add your code here