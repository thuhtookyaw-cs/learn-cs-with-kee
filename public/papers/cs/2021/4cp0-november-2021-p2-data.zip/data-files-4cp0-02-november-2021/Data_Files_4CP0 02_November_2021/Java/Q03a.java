import java.util.Scanner;

public class Q03a {

    // Subprogram to get and validate the month number -----------------------------------------
    private static int display()
    {
        int monthNumber = 0;
        Scanner input = new Scanner(System.in);
        
        while (monthNumber < 1 || monthNumber > 12)
        {
           System.out.print("Enter the month number [1 to 12] ");
           monthNumber = Integer.parseInt(input.nextLine());	 
        }
        input.close();
        return monthNumber;
    } // End of subprogram display -------------------------------------------------------------
    
    // Subprogram to show the name of the month and the number of days in the month ------------
    private static void showMonthNameAndDays(int pMonth)
    {
       // Month number, days in the month and month name
        String[][] monthsAndDays = {
                {"1", "31", "January"},
                {"2", "28", "February"},
                {"3", "31", "March"},
                {"4", "30", "April"},
                {"5", "31", "May"},
                {"6", "31", "June" },
                {"7", "31", "July"},
                {"8", "31", "August"},
                {"9", "31", "September"},
                {"10", "31", "October"},
                {"11", "31", "November"},
                {"12", "31", "December"}};
        
        int count = 0;
        boolean found = false;

        while (count < monthsAndDays.length && found == false)
        {       
            if (monthsAndDays[count][0].equals(Integer.toString(pMonth)))
            {
                found = true;
                System.out.print(monthsAndDays[count][2] + " has " + monthsAndDays[count][1] + " days");
            }
            count ++;
        }
    } // End of subprogram showMonthNameAndDays ------------------------------------------------
    
    public static void main(String[] args) {
       int monthInput = display();
       showMonthNameAndDays(monthInput);
    } // End of main program  
} // End of class