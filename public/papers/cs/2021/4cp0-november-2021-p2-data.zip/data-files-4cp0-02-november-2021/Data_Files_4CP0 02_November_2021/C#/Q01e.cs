﻿using System;

namespace Q01e
{
    class Q01e
    {
        static void Main(string[] args)
        {
            // Print prompt and get number from user
           



            // Create loop to display the table
            




            
        } // End of main program
    } // End of class
} // End of namespace